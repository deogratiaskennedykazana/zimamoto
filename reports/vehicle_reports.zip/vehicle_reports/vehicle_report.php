<?php
    require_once "../../configs.php";
    require_once "../../functions/subsidiary_functions.php";
    require_once "../../functions/vehicle_functions.php";
    require_once "../../functions/cosignment_functions.php";
    require_once "../../functions/order_functions.php";
    require_once "../../functions/transaction_functions.php";
    
    

    $conn = openConn();
    $costBalance =0;
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vehicle Report</title>
        <link rel="stylesheet" href="../../dist/css/adminlte.css">

    </head>
    <body class=' m-2'>
        <div class=" card card-primary">
            <div class=" card-header"><h5>Vehicle details</h5></div>
            <div class=" card-body">
                <h6 class=''>Vehicle Details</h6>
                <?php   
                        // $vehicl_sub = 0;
                        $vehicleId = (int) $conn->real_escape_string($_GET['vehicle_id']);
                        $vehicleDetails = selectVehicleById($conn,$vehicleId);
                        if($vehicleDetails && is_array($vehicleDetails)){
                           // print_r($vehicleDetails);
                            $vehicl_sub = $vehicleDetails['subsisiary_id'];
                            ?>
                                <div class=' row'>
                                    <div class=' col-5 '>
                                        <label for=""> Plate No: <?= $vehicleDetails['registration_number'] ?> </label> <br>
                                        <label for=""> Manufacturer: <?= $vehicleDetails['manufacturer'] ?> </label><br>
                                        <label for=""> Model Number: <?= $vehicleDetails['model_number'] ?> </label><br>
                                        <label for=""> Type: <?= $vehicleDetails['type'] ?> </label><br>
                                        <label for=""> Initial Kilometer: <?= $vehicleDetails['initial_distance'] ?> </label><br>
                                    </div>
                                    <div class=' col-5 '>
                                        <label for=""> Purchase date: <?= $vehicleDetails['purchase_date'] ?> </label> <br>
                                        <label for=""> Insurance Issue Date: <?= $vehicleDetails['insurance_date'] ?> </label><br>
                                        <?php
                                                    $insuranceDate = $vehicleDetails['insurance_date']; // Example: '2024-12-16'

                                                    try {
                                                        $insuranceDateObj = new DateTime($insuranceDate); // Create a DateTime object
                                                        $expiryDate = (clone $insuranceDateObj)->modify('+1 year'); // Add 1 year to get the expiry date
                                                    
                                                       
                                                        echo "<label>Insurance Renew Date: " . $expiryDate->format('Y-m-d') . "</label>";
                                                    } catch (Exception $e) {
                                                        echo "Error: " . $e->getMessage(); // Handle invalid date formats
                                                    }
                                        
                                        ?>
                                       
                                        <label for=""> Capacity: <?= $vehicleDetails['capacity'] ?> </label><br>
                                        <label for=""> Status: <?= $vehicleDetails['status'] ?> </label><br>
                                    </div>
                                </div>
                            <?php
                       

               
                  //get consignemnt in a given vehicle    
                  $consigns = selectConsignmentByVehicleInvolved($conn, $vehicleId);
                  if($consigns && is_array($consigns)){
                    //  print_r($consigns);
                    ?>
                        <div class=" m-2">
                            <h4>Route Travelled</h4>
                            <table class=' table-sm table'>
                                <tr class=' bg-info'>
                                    <td>#</td>
                                    <td>Route Name</td>
                                    <td>Distance (in Km)</td>
                                    <td>Date start </td>
                                    <td>Date end</td>
                                </tr>
                                <?php
                                         $counter =1;
                                        foreach($consigns as $route){
                                            //route involved
                                                $orderId = $route['order_id'];
                                                $routes = selectOrderRoutesByRouterId($conn, $orderId);
                                                //print_r($routes);
                                                if($routes && is_array($routes)){
                                                   
                                                    foreach($routes as $route1){
                                                        echo "<tr>";
                                                            echo "<td>$counter</td>";
                                                            echo "<td>$route1[from_] - $route1[to_]</td>";
                                                            echo "<td>$route[distance] </td>";
                                                            echo "<td>$route[shipment_date] </td>";
                                                           
                                                            echo "<td>$route[return_date] </td>";
                                                        echo "</tr>";
                                                        
                                                    }
                                               
                                                }
                                                $counter++;
                                           }
                                        }    
                                ?>
                            </table>
                            <!-- involved cost -->
                                <h4 class=' form-label'>Involved Cost</h4>
                                <table class=' table-sm table'>
                                    <tr class=' bg-info'>
                                        <td>#</td>
                                        <td>Date</td>
                                        <td>Cost Item </td>
                                        <td>Amount</td>

                                    </tr>
                                    <?php
                                        // foreach($consigns as $driver){
                                        //         $driverId = $driver['driver_id'];
                                        //         $consignId = $driver['id'];
                                        //         $transaction = selectAllDebitTransactionsBySubIdAndRef($conn, $driverId, $consignId);
                                        //         if($transaction && is_array($transaction)){
                                        //             print_r($transaction);

                                        //         }

                                        // }
                                        $counter = 1;
                                        $transactions = selectAllCreditTransactionsBySubIdAndRef($conn,(int) $conn->real_escape_string($vehicleDetails['subsisiary_id']));
                                      //  print_r($transactions);
                                        if($transactions && is_array($transactions)){
                                               
                                            foreach($transactions as $transaction){
                                            
                                                echo "<tr>";
                                                    
                                                      echo "<td>$counter</td>";
                                                      echo "<td>$transaction[date_]</td>";
                                                        echo "<td>$transaction[name]</td>";
                                                        
                                                        echo "<td>". number_format( $transaction['dr_ammount'],) ."</td>";
                                                echo "</tr>";
                                                $costBalance += $transaction['dr_ammount'];
                                                $counter++;
                                            }
                                        }
                                        $payments =  selectVehiclePayment($conn, (int) $conn->real_escape_string($_GET['vehicle_id']), "payment");
                                        if($payments && is_array($payments)){
                                            foreach($payments as $payment){
                                                echo "<tr>";
                                                        echo "<td>$counter</td>";
                                                        echo "<td>$payment[date_]</td>";
                                                        echo "<td>$payment[paid_to]</td>";
                                                        echo "<td>". number_format( $payment['dr_ammount'],2)."</td>";
                                                echo "</tr>";
                                                $costBalance += $payment['dr_ammount'];
                                                $counter++;
                                            }
                                        }

                                        echo "<tr><td  colspan='3'>Total </td><td> ". number_format( $costBalance,1) ."</td></tr>";
                                    ?>
                                </table>
                        </div>
                     <?php
                    
                  
                }
                 ?>
                   
            </div>
            <div class=' card-footer'> -- End -- </div>
        </div>
        <?php
        
        ?>
    </body>
    </html>
    <?php












    closeConn($conn);
  

?>